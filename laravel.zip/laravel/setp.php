Install xampp with 3.3.0
install composer = php composer.phar install
create laravel app - composer create-project --prefer-dist laravel/laravel:^10 but am facing php version problem thats why created laravel app with version 8