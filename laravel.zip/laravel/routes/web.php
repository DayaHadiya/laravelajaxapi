<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [UserController::class, 'user']);
Route::get('getcity/{id}', [UserController::class, 'city'])->name('getcity');
Route::post('adduser', [UserController::class, 'addUser'])->name('adduser');
Route::post('edituser', [UserController::class, 'editUser'])->name('edituser');
Route::get('/getuser', [UserController::class, 'getuser'])->name('getuser');
Route::get('/deleteuser/{uid}', [UserController::class, 'deleteuser'])->name('deleteuser');


