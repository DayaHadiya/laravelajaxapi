<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Hobby;
use Illuminate\Support\Facades\File; 

class UserController extends Controller
{
    public function add(Request $request)
    {
        /*$validator = Validator::make($request->all(), [
            'm_name' => 'required',
            'email'=> 'required|unique:users',
            'm_phone'=> 'required',
            'm_hobby' => 'required',
            'm_gender' => 'required',
            'file' => 'required',
            'state_id' => 'required',
            'city_id' => 'required'
        ]);
        if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
         */
        $input = $request->all();
        $input['name'] = $input['m_name'];
        $input['email'] = $input['email'];
        $input['gender'] = $input['m_gender'];
        $input['phone'] = $input['m_phone'];

        $input['hobby'] = $input['m_hobby'];
        $input['city_id'] = $input['city_id'];
        $input['state_id'] = $input['state_id'];
        $imagePath = $input['file'];
        $filename = rand(0000,9999).$imagePath->getClientOriginalName();
        $extension  = pathinfo($imagePath->getClientOriginalName(), PATHINFO_EXTENSION);
        $filename = rand(0000,9999)."userpic.".$extension;
        $upload_dir_path = public_path()."/images";
        $imagePath->move($upload_dir_path, $filename );
        $input['image'] = $filename;
        $userImage = asset('images/'.$filename);
        $input['remember_token'] = md5(rand(1,999999));
        $input['password'] = bcrypt('123');

        /*$imagePath = $input['m_image'];
        $extension  = pathinfo($imagePath->getClientOriginalName(), PATHINFO_EXTENSION);
        $filename = rand(0000,9999)."user.".$extension;
        $upload_dir_path = public_path()."/images";
        $imagePath->move($upload_dir_path, $filename );
        $input['image'] = $filename;*/

        $u = User::create($input);

        foreach($input['m_hobby'] as $h)
        {
            $hobby['name'] = $h->hobby;
            $hobby['user_id'] = $u->id;
            Hobby::create($hobby);
        }
        $data = 'success';
        return response()->json(['status'=>1,'message'=>$data]); 
    }

    public function edit(Request $request)
    {
        
        $input = $request->all(); 

        $update = array();
        $update['name'] = $input['m_name'];
        $update['email'] = $input['m_email'];
        $update['gender'] = $input['m_gender'];
        $update['phone'] = $input['m_phone'];
        $update['state_id'] = $input['m_state'];
        $update['city_id'] = $input['m_city'];

        $imagePath = $input['file'];
        if(isset($input['file']) && $input['file'] != "undefined"){
            $filename = rand(0000,9999).$imagePath->getClientOriginalName();
            $extension  = pathinfo($imagePath->getClientOriginalName(), PATHINFO_EXTENSION);
            $filename = rand(0000,9999)."userpic.".$extension;
            $upload_dir_path = public_path()."/images";
            $imagePath->move($upload_dir_path, $filename );
            $update['image'] = $filename;
            $userImage = asset('images/'.$filename);
        }
        $update['token'] = md5(rand(1,999999));

        User::where('id',$input['mid'])->update($update);
        foreach($input['m_hobby'] as $h)
        {
            Hobby::where('name',$h->name)->where('user_id',$input['mid'])->delete();
            $hobby['name'] = $h->hobby;
            $hobby['user_id'] = $input['mid'];
            Hobby::create($hobby);
        }

        $data = 'success';
        return response()->json(['status'=>1,'message'=>$data]); 
    }

    

    
}
