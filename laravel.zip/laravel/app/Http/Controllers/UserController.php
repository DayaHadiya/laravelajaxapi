<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\State;
use App\Models\City;

class UserController extends Controller
{
    public function user()
    {
    	$user = User::get();
    	$state = State::get();
    	return view('user',compact('user','state'));
    }

    public function city($id)
    {
    	$city = City::where('state_id',$id)->get();

    	$output = "";
    	foreach($city as $c)
        {
            $output .='<option value="'.$c->id.'">'.$c->name.'</option>';
            
        }
        
        echo $output;
    }

    public function addUser(Request $request)
    {
    	$validator = Validator::make($request->all(), [
            'm_name' => 'required',
            'email'=> 'required|unique:users',
            'm_phone'=> 'required',
            'm_hobby' => 'required',
            'm_gender' => 'required',
            'file' => 'required',
            'm_state' => 'required',
            'm_city' => 'required'
        ]);
        if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }

        $input = $request->all(); 

		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => 'localhost:8000/api/adduser',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => array('m_name' => $input['m_name'],'email' => $input['email'],'m_phone' => $input['m_phone'],'m_hobby' => $input['m_hobby'],'m_gender' => $input['m_gender'],'file'=> $input['file'],'state_id' => $input['m_state'],'city_id' => $input['m_city']),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		//echo $response;
		$data = 'success';
        return $data;

	}

	public function editUser(Request $request)
	{
		$validator = Validator::make($request->all(), [
            'm_name' => 'required',
            'email'=> 'required|unique:users',
            'm_phone'=> 'required',
            'm_hobby' => 'required',
            'm_gender' => 'required',
            'file' => 'required',
            'm_state' => 'required',
            'm_city' => 'required'
        ]);
        if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }

        $input = $request->all(); 

		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => 'localhost:8000/api/edituser',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => array('m_name' => $input['m_name'],'email' => $input['email'],'m_phone' => $input['m_phone'],'m_hobby' => $input['m_hobby'],'m_gender' => $input['m_gender'],'file'=> $input['file'],'state_id' => $input['m_state'],'city_id' => $input['m_city'],'mid',$input['mid']),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		//echo $response;
		$data = 'success';
        return $data;
	}

	public function getuser()
    {
        $user = User::get();
        $output = '';
        $img = asset('/images/');
        foreach($user as $u)
        {
            $output .='<tr><td><img src='.$img.'/'.$u->image.' width="70px" height="80px"></td>';
            $output .='<td>'.$u->name.'</td>';
            $output .='<td>'.$u->email.'</td>';
            $output .='<td>'.$u->gender.'</td>';
            $output .='<td>'.$u->hobby.'</td>';
            $output .='<td ><button class="btn btn-light edit-form" style="color: green"data-toggle="modal" data-id="'.$u->id.'" data-name="'.$u->name.'" data-email="'. $u->email.'" data-bs-target="#editModal">edit</button><button class="btn btn-light" style="color: red" onclick="deleteUser('.$u->id.')">delete</button><button class="btn btn-light" style="color: blue" onclick="pdfCreate('.$u->id.')" >pdf</button><button class="btn btn-light" style="color: gray" onclick="docCreate('.$u->id.')">doc</button></td>';
            $output .='</tr>';
        }
        
        echo $output;
    }

    public function deleteuser($uid)
    {
        $user = User::where('id',$uid)->delete();
        return response()->json(['status'=>1,'message'=>$user]); 
    }
}
