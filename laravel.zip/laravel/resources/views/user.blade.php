
<!DOCTYPE html>
<html>
<head>
	<title>User Data</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	
</head>
<body>
	<?php 
		$formRoute = 'loginsubmit';
	?>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-5" style="padding-top: 50px;">
				<div style="align-items: center ">
				<h3 > User Data</h3>
				</div>
			</div>
			<div class="col-md-1" style="padding-top: 70px;">
				<button type="button" class="btn btn-info" data-target="#addusermodal" data-toggle="modal" >Add User</button>
			</div>
		</div>
	</nav>
	<div class="col-md-2"></div>
	<div class="col-md-8">
		
		
		@if($errors->any())
            <div class="error-message-box">                    
                <p>{{$errors->first()}}</p>
            </div>
        @endif
		 
	  	<table class="table">
		  <thead>
		    <tr>
		      <th scope="col">Profile</th>
		      <th scope="col">Name</th>
		      <th scope="col">Email</th>
		      <th scope="col">Gender</th>
		      <th scope="col">Hobby</th>
		      <th >Action</th>
		    </tr>
		  </thead>
		  <tbody id="userList">
		  	@foreach($user as $u)
			    <tr >
			      <td><img src="{{ asset('/images/'.$u->image) }}" width="70px" height="80px"></td>
			      <td>{{$u->name}}</td>
			      <td>{{$u->email}}</td>
			      <td>{{$u->gender}}</td>
			      <td>{{$u->hobby}}</td>
			      <td ><button class="btn btn-light edit-form" style="color: green"data-toggle="modal"  data-mid ="{{ $u->id }}" data-mimage ="{{ $u->image }}" data-mname ="{{ $u->name }}" data-memail="{{ $u->email }}"  data-mgender="{{ $u->gender }}" data-mmobile="{{ $u->phone }}" data-mhobby="{{ $u->hobby }}" data-mstate="{{ $u->state_id }}" data-mcity="{{ $u->city_id }}" data-bs-target="#editModal">edit</button><button class="btn btn-light" style="color: red" onclick="deleteUser('{{$u->id}}')">delete</button></td>
			    </tr>
		    @endforeach
		  </tbody>
		</table>
	</div>

	<div class="modal fade" id="addusermodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLongTitle">Add User</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
            <div class="error-message-box" id="errorData">                    
                
            </div>
	        <form method="post" enctype="multipart/form-data" action="">
	        	@csrf
	        	<div class="form-group">
		            <label  class="col-form-label" id="em_image">Profile:</label>
		            <input type="file" class="form-control" id="m_image" name="m_image">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_name">Name:</label>
		            <input type="text" class="form-control" id="m_name" name="m_name">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_email">Email:</label>
		            <input type="email" class="form-control" id="m_email" name="m_email">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_gender">Gender:</label>
		            <input type="radio"  id="m_gender" name="m_gender">Female
		            <input type="radio"  id="m_gender" name="m_gender">Male
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_phone">Mobile:</label>
		            <input type="text" class="form-control" id="m_phone" name="m_phone">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_hobby">Hobby:</label>
		            <select  class="form-control" id="m_hobby" name="m_hobby[]" multiple="true">
		            	<option disabled="true" hidden="true">--Select--</option>
		            	<option value="Cooking">Cooking</option>
		            	<option value="Art">Art</option>
		            	<option value="Singing">Singing</option>
		            	<option value="Sports">Sports</option>
		            	<option value="Reading">Reading</option>
		            </select>
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_state">State:</label>
		            <select  class="form-control" id="m_state" name="m_state" >
		            	<option disabled="true" hidden="true">--Select--</option>
		            	@foreach($state as $s)
		            		<option value="{{$s->id}}">{{$s->name}}</option>
		            	@endforeach
		            </select>
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="em_city">City:</label>
		            <select  class="form-control" id="m_city" name="m_city" >
		            	<option disabled="true" hidden="true">--Select--</option>
		            </select>
		          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-primary" id="adduser" name="adduser" onclick="adduserdata();">Add User</button>
	      </div>
	    </div>
	  </div>
	</div>

	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <form method="post" enctype="multipart/form-data" action="">
	        	@csrf
	        	<input type="hidden" name="mid" id="mid">
	        	<div class="form-group">
		            <label  class="col-form-label" >Profile:</label>
		            <input type="file" class="form-control" id="mimage" name="mimage">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="emname">Name:</label>
		            <input type="text" class="form-control" id="mname" name="mname">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="ememail">Email:</label>
		            <input type="email" class="form-control" id="memail" name="memail">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="emgender">Gender:</label>
		            <input type="text" class="form-control" id="mgender" name="mgender">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="emmobile">Mobile:</label>
		            <input type="text" class="form-control" id="mmobile" name="mmobile">
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="emhobby">Hobby:</label>
		            <select  class="form-control" id="mhobby" name="mhobby[]" multiple="true">
		            	<option disabled="true" hidden="true">--Select--</option>
		            	<option value="Cooking">Cooking</option>
		            	<option value="Art">Art</option>
		            	<option value="Singing">Singing</option>
		            	<option value="Sports">Sports</option>
		            	<option value="Reading">Reading</option>
		            </select>
		          </div>
		           <div class="form-group">
		            <label  class="col-form-label" id="emstate">State:</label>
		            <select  class="form-control" id="mstate" name="mstate" >
		            	<option disabled="true" hidden="true">--Select--</option>
		            	@foreach($state as $s)
		            		<option value="{{$s->id}}">{{$s->name}}</option>
		            	@endforeach
		            </select>
		          </div>
		          <div class="form-group">
		            <label  class="col-form-label" id="emcity">City:</label>
		            <select  class="form-control" id="mcity" name="mcity" >
		            	<option disabled="true" hidden="true">--Select--</option>
		            </select>
		          </div>
	        </form>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-primary" onclick="submitEdit();">Save changes</button>
	      </div>
	    </div>
	  </div>
	</div>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
 <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript">
	
	$(document).on('click', '.edit-form', function(e) {
	    e.preventDefault();
	    $("#mid").val($(this).attr('data-mid'));
	    $("#mname").val($(this).attr('data-mname'));
	    $("#memail").val($(this).attr('data-memail'));
	    $("#mgender").val($(this).attr('data-mgender'));
	    $("#mmobile").val($(this).attr('data-mmobile'));
	    $("#mcity").$('#mhobby option[value="'+$(this).attr('data-mcity')+'"]').prop('selected', true);
	    $("#mstate").$('#mhobby option[value="'+$(this).attr('data-mstate')+'"]').prop('selected', true);
	    split_string = ($(this).attr('data-mhobby')).split(",");
	    split_string.forEach(element => {
	    	$('#mhobby option[value="'+element+'"]').prop('selected', true);
	    	
	    });
	    
	    $('#exampleModal').modal('show');

	});

	function submitEdit(argument) {
		
		if ($('#mname').val()==null || $('#mname').val()==""){  
			$("#emame").empty();
		  	$('#emame').append('<p id="emame" style="color:red">Name can not be blank</p>');
		  return false;  
		}else{
			$("#emame").empty();
			$('#emame').append('<p id="emame" >Name:</p>');
		}

		if ($('#memail').val()==null || $('#memail').val()==""){  
			$("#ememail").empty();
		  	$('#ememail').append('<p id="ememail" style="color:red">Email can not be blank</p>');
		  return false;  
		} 
		else{
			$("#ememail").empty();
			$('#ememail').append('<p id="ememail" >Email:</p>');
		}


		if ($('#mgender').val()==null || $('#mgender').val()==""){  
			$("#emgender").empty();
		  	$('#emgender').append('<p id="emgender" style="color:red">Gender can not be blank</p>');
		  return false;  
		} 
		else{
			$("#emgender").empty();
			$('#emgender').append('<p id="emgender"">Gender:</p>');
		}

		if ($('#mphone').val().length<6){  
			$("#emphone").empty();
		  	$('#emphone').append('<p id="emphone" style="color:red">Mobile must be at least 6 characters long</p>');
		  return false;  
		} 
		else{
			$("#emphone").empty();
			$('#emphone').append('<p id="emphone" ">Mobile:</p>');
		}
		if ($('#mhobby').val()==null || $('#mhobby').val()==""){  
			$("#emhobby").empty();
		  	$('#emhobby').append('<p id="emhobby" style="color:red">Hobby can not be blank</p>');
		  return false;  
		} 
		else{
			$("#emhobby").empty();
			$('#emhobby').append('<p id="emhobby"">Hobby:</p>');
		}
		 

		var formData = new FormData();
		var file = $('#mimage').prop('files')[0];

		formData.append('file', file);
		formData.append('mid', $('#mid').val());
		formData.append('m_name', $('#mname').val());
		formData.append('m_email', $('#memail').val());
		formData.append('m_gender', $('#mgender').val());
		formData.append('m_mobile', $('#mmobile').val());
		formData.append('m_hobby', $('#mhobby').val());
		formData.append('m_state', $('#mstate').val());
		formData.append('m_city', $('#mcity').val());
		formData.append('_token', '{{csrf_token()}}');
		JSON.stringify(formData);

		$.ajax({
			type:"POST",
			url : '/edituser',
			data : formData,
			processData: false,
    		contentType: false,
    		dataType: 'text',
    		success: function (msg) {
		       //alert(msg);
				$("#emname").empty();
				$("#ememail").empty();
				$("#emgender").empty();
				$("#emmobile").empty();
				$("#emhobby").empty();
		    	if(msg.m_name){  $('#emname').append('<p id="pem_name" style="color:red">'+msg.mname+'</p>'); }
		    	if(msg.memail){  $('#ememail').append('<p id="pememail" style="color:red">'+msg.memail+'</p>'); }
		    	
		    	if(msg.mgender){  $('#emgender').append('<p id="pemgender" style="color:red">'+msg.mgender+'</p>'); }
		    	if(msg.mmobile){  $('#emmobile').append('<p id="pemmobile" style="color:red">'+msg.mmobile+'</p>'); }
		    	if(msg.mhobby){  $('#emhobby').append('<p id="pemhobby" style="color:red">'+msg.mhobby+'</p>'); }
		    	
		    	if(msg == 'success')
		    	{
		    		listUser();
		    		$('#exampleModal').modal('hide');
		    	}
		    },
		    error: function () {
		        OnError(cartObject.productID);
		    },
			/*data : {'m_name' :m_name ,'m_email' :m_email ,'m_password' :m_password ,'m_gender' :m_gender ,'m_mobile' :m_mobile ,'m_hobby' :m_hobby ,'m_address' :m_address,'m_image' :m_image,'_token':'{{ csrf_token() }}'},*/
		});
	}
	    

	function adduserdata() {

		if ($('#m_image').val()==null || $('#m_image').val()==""){  
			$("#em_image").empty();
		  	$('#em_image').append('<p id="em_image" style="color:red">Image can not be blank</p>');
		  return false;  
		}else{
			$("#em_name").empty();
			$('#em_name').append('<p id="em_name" >Name:</p>');
		}

		if ($('#m_name').val()==null || $('#m_name').val()==""){  
			$("#em_name").empty();
		  	$('#em_name').append('<p id="em_name" style="color:red">Name can not be blank</p>');
		  return false;  
		}else{
			$("#em_name").empty();
			$('#em_name').append('<p id="em_name" >Name:</p>');
		}

		if ($('#m_email').val()==null || $('#m_email').val()==""){  
			$("#em_email").empty();
		  	$('#em_email').append('<p id="em_email" style="color:red">Email can not be blank</p>');
		  return false;  
		} 
		else{
			$("#em_email").empty();
			$('#em_email').append('<p id="em_email" >Email:</p>');
		}

		if ($('#m_gender').val()==null || $('#m_gender').val()==""){  
			$("#em_gender").empty();
		  	$('#em_gender').append('<p id="em_gender" style="color:red">Select Gender</p>');
		  return false;  
		} 
		else{
			$("#em_gender").empty();
			$('#em_gender').append('<p id="em_gender" ">Gender:</p>');
		}

		if ($('#m_phone').val().length<6){  
			$("#em_phone").empty();
		  	$('#em_phone').append('<p id="em_phone" style="color:red">Mobile must be at least 6 characters long</p>');
		  return false;  
		} 
		else{
			$("#em_phone").empty();
			$('#em_phone').append('<p id="em_phone" ">Mobile:</p>');
		}

		if ($('#m_hobby').val()==null || $('#m_hobby').val()==""){  
			$("#em_hobby").empty();
		  	$('#em_hobby').append('<p id="em_hobby" style="color:red">Hobby can not be blank</p>');
		  return false;  
		} 
		else{
			$("#em_hobby").empty();
			$('#em_hobby').append('<p id="em_hobby" ">Hobby:</p>');
		}
		if ($('#m_state').val()==null || $('#m_state').val()==""){  
			$("#em_state").empty();
		  	$('#em_state').append('<p id="em_state" style="color:red">Address can not be blank</p>');
		  return false;  
		}
		else{
			$("#em_state").empty();
			$('#em_state').append('<p id="em_state" ">State:</p>');
		} 

		if ($('#m_city').val()==null || $('#m_city').val()==""){  
			$("#em_city").empty();
		  	$('#em_city').append('<p id="em_city" style="color:red">Address can not be blank</p>');
		  return false;  
		}
		else{
			$("#em_city").empty();
			$('#em_city').append('<p id="em_city" ">City:</p>');
		}  
		  
		var formData = new FormData();
		var file = $('#m_image').prop('files')[0];

		
		formData.append('file', file);
		formData.append('m_name', $('#m_name').val());
		formData.append('email', $('#m_email').val());
		formData.append('m_gender', $('#m_gender').val());
		formData.append('m_phone', $('#m_phone').val());
		formData.append('m_hobby', $('#m_hobby').val());
		formData.append('m_city', $('#m_city').val());
		formData.append('m_state', $('#m_state').val());
		formData.append('_token', '{{csrf_token()}}');
		JSON.stringify(formData);

		$.ajax({
			type:"POST",
			url : '/adduser',
			data : formData,
			dataType: 'text',
			processData: false,
			contentType: false,
			/*data : {'m_name' :m_name ,'m_email' :m_email ,'m_password' :m_password ,'m_gender' :m_gender ,'m_mobile' :m_mobile ,'m_hobby' :m_hobby ,'m_address' :m_address,'m_image' :m_image,'_token':'{{ csrf_token() }}'},*/
			success: function (msg) {
		       //alert(msg);
		       $("#pem_name").empty();
				$("#pem_email").empty();
				$("#pem_password").empty();
				$("#pem_gender").empty();
				$("#pem_mobile").empty();
				$("#pem_hobby").empty();
				$("#pem_address").empty();
		    	if(msg.m_name){  $('#em_name').append('<p id="pem_name" style="color:red">'+msg.m_name+'</p>'); }
		    	if(msg.m_email){  $('#em_email').append('<p id="pem_email" style="color:red">'+msg.m_email+'</p>'); }
		    	if(msg.m_gender){  $('#em_gender').append('<p id="pem_gender" style="color:red">'+msg.m_gender+'</p>'); }
		    	if(msg.m_mobile){  $('#em_mobile').append('<p id="pem_mobile" style="color:red">'+msg.m_mobile+'</p>'); }
		    	if(msg.m_hobby){  $('#em_hobby').append('<p id="pem_hobby" style="color:red">'+msg.m_hobby+'</p>'); }
		    	if(msg.m_address){  $('#em_address').append('<p id="pem_address" style="color:red">'+msg.m_address+'</p>')}
		    	if(msg == 'success')
		    	{	
			       	listUser();
			    	$('#addusermodal').modal('hide');
			    }
		      },
		     error: function () {
		        OnError(cartObject.productID);
		      },
		});
	}

	function listUser(){
		$.ajax({
		    type: "get",
		    url: '/getuser', 
		}).done(function( data ) {
		    $('#userList').html(data);
		});
	}

	function deleteUser(uid){
		$.ajax({
		    type: "get",
		    url: '/deleteuser/'+uid, 
		}).done(function( data ) {
		    listUser();
			alert(data);
		});
	}

	$('#m_state').change(function () {
    	var s_id = this.value;
    	$.ajax({
		    type: "get",
		    url: '/getcity/'+s_id, 
		}).done(function( data ) {
		    $('#m_city').html(data);
		});
	});

	$('#mstate').change(function () {
    	var s_id = this.value;
    	$.ajax({
		    type: "get",
		    url: '/getcity/'+s_id, 
		}).done(function( data ) {
		    $('#mcity').html(data);
		});
	});

</script>
</html>
